<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DanhSachBD extends Model
{
    //
    protected $table = "danh_sach_bd";
    public $timestamps = false;
}
