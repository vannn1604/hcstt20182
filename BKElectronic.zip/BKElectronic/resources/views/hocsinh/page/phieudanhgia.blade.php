@extends('hocsinh.layout.index')
@section('content')
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Nhận xét</h3>
    </div>
    <div class="panel-body">
        <ul>
            <li style="list-style: disc;">Còn mắc một số lỗi chính tả. Em cần rèn luyện chữ viết nhiều hơn.</li>
            <li style="list-style: disc;">Tính toán còn chậm, còn nhiều sai sót. Cần rèn nhiều về nhân, chia, giải toán có lời văn.</li>
            <li style="list-style: disc;">Hoàn thành tốt nội dung môn học.</li>
        </ul>
    </div>
@endsection