@extends('vanthu.layout.index')
@section('content')
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3>Thêm thư báo</h3>
</div>
<!-- /.col-lg-12 -->

<div class="panel-body">
    @if(count($errors)>0)
    <div class="alert alert-danger">
        @foreach($errors->all() as $err)
        {{$err}}<br>
        @endforeach
    </div>
    @endif
    @if(session('thongbao'))
    <div class="alert alert-danger">
        {{session('thongbao')}}
    </div>
    @endif
    @if(session('thanhcong'))
    <div class="alert alert-success">
        {{session('thanhcong')}}
    </div>
    @endif
    <form role="form" action="{{ url('vanthu/thubao/themthubao') }}" method="POST" enctype="multipart/form-data">
        {!! csrf_field() !!}
        <div class="form-group">
            <label>Tiêu Đề</label>
            <input class="form-control" name="tieude" placeholder="" />
        </div>
        <div class="form-group">
            <label>Tóm tắt</label>
            <textarea class="form-control" rows="3" name="tomtat"></textarea>
        </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea id="demo" class="ckeditor form-control" rows="3" name="noidung"></textarea>
        </div>
        <div class="form-group">
            <label>Chọn ảnh</label>
            <input type="file" name="Hinh">
        </div>
        <button type="submit"  class="btn btn-primary">Thêm</button>
        <button type="reset" class="btn btn-default">Làm mới</button>
    <form>
</div>

        @endsection