<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThuBao extends Model
{
    //
    protected $table = "thu_bao";
    public $timestamps = false;
}
