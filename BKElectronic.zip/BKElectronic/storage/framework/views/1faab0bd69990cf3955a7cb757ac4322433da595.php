<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Đánh giá</h3>
    </div>
    <div class="panel-body">
        <table class="table table-bordered table-striped">
       <?php
        $i=1;

        ?>

            <thead>
            <tr class="info">
                <th>STT</th>
                <th>Họ tên</th>
                <th>Điểm TB</th>
                <th>Học lực</th>
                <th>Hạnh kiểm</th>
                <th>Nhận xét</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $hocsinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $tongket = \App\BangTongKet::Where('id_hocsinh', $hs['id'])->first();
                ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($hs['ho_ten']); ?></td>
                    <td><?php echo e($tongket['diem_phay_cuoi']); ?></td>
                    <td><?php echo e($tongket['hoc_luc']); ?></td>
                    <td style="position: relative;"><?php echo e($tongket['hanh_kiem']); ?></td>
                    <td style="position: relative;"><?php echo e($tongket['nhan_xet']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="giaovien/danhgia" class="btn btn-default" style="float: right; margin-left: 5px;">Hủy bỏ</a>
        <a href="giaovien/danhgia/nhap/<?php echo e($id_lop); ?>/<?php echo e($id_giaovien); ?>" class="btn btn-primary" style="float: right; ">Cập nhật</a>
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/giaovien/page/detaldanhgia.blade.php ENDPATH**/ ?>