<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CuoiKiC1 extends Model
{
    //
    protected $table = "cuoi_ki_c1";
    public $timestamps = false;
}
