<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <div class="semyear-choice">
            <ul>
                <li>
                </li>
            </ul>
        </div>
    </div>
    <div class="panel-body">
        <table class="table table-bordered">
            <caption style="text-align: center; font-size: 15px; font-weight: bold;">Danh sách lớp <?php echo e($lop['ten_lop']); ?></caption>
            <thead>
            <tr class="info">
                <th>STT</th>
                <th>Họ tên</th>
                <th>Địa chỉ</th>
                <th>Sửa</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i=1
            ?>
            <?php $__currentLoopData = $hocsinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($hs['ho_ten']); ?></td>
                    <td><?php echo e($hs['dia_chi']); ?></td>
                    <td><a href="vanthu/hocsinh/dshocsinh/sua/<?php echo e($hs['id']); ?>" style="color:#337AB7;">Sửa</a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vanthu.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/vanthu/hocsinh/detaldshocsinh.blade.php ENDPATH**/ ?>