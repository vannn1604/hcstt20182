<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3 class="table-title"><i class="fa icon-envelope"></i>Thư báo từ trường <strong id="TotalRow_show"></strong></h3>
    </div>

    <div class="panel-body" style="padding: 0;">
        <div>
            <table class="table table-striped">
                <tbody id="tbdList">
                <?php $__currentLoopData = $thubao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-id="showdetail" data-sendmsgrequestid="SR2019041310040">
                            <div class="cont" style="color: rgb(0, 0, 0);font-weight: bold;">Thông báo:<?php echo e($tb['tieu_de']); ?></div>
                            <div class="cont"><?php echo e($tb['tom_tat']); ?></div>
                            <div style="float:left;width:50%" class="date"><i class="fa icon-clock-o"></i><?php echo e($tb['created_at']); ?></div>
                            <div><a href="giaovien/thubao/<?php echo e($tb['id']); ?>" style="cursor: pointer;float: right;font-size: 12px;font-weight: bold;" data-id="showdetail " data-sendmsgrequestid="SR2019041310040">›› Xem chi tiết</a></div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
                
            
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/giaovien/index.blade.php ENDPATH**/ ?>