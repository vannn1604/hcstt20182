<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LopDay extends Model
{
    //
    protected $table = "lop_day";
    public $timestamps = false;
}
