<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GiaoVien extends Model
{
    //
    protected $table = "giao_vien";
    public $timestamps = false;
}
