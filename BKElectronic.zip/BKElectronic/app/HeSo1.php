<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeSo1 extends Model
{
    //
    protected $table = "he_so1";
    public $timestamps = false;
}
