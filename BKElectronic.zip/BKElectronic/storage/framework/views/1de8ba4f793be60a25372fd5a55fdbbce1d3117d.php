<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Thông tin cơ bản</h3>
    </div>

    <div class="panel-body">
        <table class="table table-bordered table-striped">
            <tr>
                <th>Họ tên</th>
                <td><?php echo e($giaovien['ho_ten']); ?></td>
            </tr>
            <tr>
                <th>Giới tính</th>
                <td><?php echo e($giaovien['gioi_tinh']); ?></td>
            </tr>
            <tr>
                <th>Mã Giáo Viên</th>
                <td>GV<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?></td>
            </tr>
            <tr>
                <th>Trường học</th>
                <td><?php echo e($truong['ten_truong']); ?></td>
            </tr>
            <tr>
                <th>Địa chỉ</th>
                <td><?php echo e($giaovien['dia_chi']); ?></td>
            </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web_Technologies_and_e-Services_project\BKElectronic\resources\views/giaovien/page/tttaikhoan.blade.php ENDPATH**/ ?>