<div class="row main-left">
    <div class="col-md-3 ">
        <ul class="list-group" id="menu">
            <?php
            ?>
            <li href="#" class="list-group-item menu1 active">Menu</li>
            <li href="" class="list-group-item menu1"><a href="giaovien/thubao">Thư báo</a></li>

            <li href="#" class="list-group-item menu1">
                <a href="giaovien/dslop">Danh sách lớp giảng dạy</a>
            </li>
            <li href="#" class="list-group-item menu1">
                <a href="giaovien/nhapdiem">Nhập điểm</a>
            </li>
            <li href="#" class="list-group-item menu1">
                <a href="giaovien/danhgia">Đánh giá tổng kết</a>
            </li>

            <li href="#" class="list-group-item menu1">
                Quản lý tài khoản
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="giaovien/taikhoan/tttaikhoan">Thông tin cá nhân</a>
                </li>
                <li class="list-group-item">
                    <a href="giaovien/taikhoan/doimatkhau">Đổi mật khẩu</a>
                </li>

            </ul>

            <li href="#" class="list-group-item menu1">
                <a href="logout">Đăng xuất</a>
            </li>
        </ul>
    </div>