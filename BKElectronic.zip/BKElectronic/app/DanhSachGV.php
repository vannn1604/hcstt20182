<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DanhSachGV extends Model
{
    //
    protected $table = "danh_sach_gv";
    public $timestamps = false;
}
