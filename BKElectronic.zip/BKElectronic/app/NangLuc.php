<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NangLuc extends Model
{
    //
    protected $table = "nang_luc";
    public $timestamps = false;
}
