<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BangDiem extends Model
{
    //
    protected $table = "bang_diem";
    public $timestamps = false;
}
