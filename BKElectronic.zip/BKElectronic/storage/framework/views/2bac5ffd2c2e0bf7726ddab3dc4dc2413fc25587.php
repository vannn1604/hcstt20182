    
<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Danh sách lớp giảng dạy</h3>
    </div>

    <div class="panel-body">
        <table class="table table-bordered table-striped">
            <thead>
            <tr class="info">
                <th>STT</th>
                <th>Tên lớp</th>
                
                <th>Môn giảng dạy</th>
                <th>Thêm điểm</th>
            </tr>
            </thead>
            <tbody>
            <?php

            ?>
            <?php
            $i=1;
            ?>

            <?php $__currentLoopData = $gvds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $lopday=\App\LopDay::Where('id_giaovien',$gv['id'])->get();
                $mon=\App\MonHoc::find($gv['id_mon']);
                $dshs1=\App\DanhSachHS::where('id_giaovien',$gv['id'])->where('id_hocki',$id_hocki)->count();
                if($dshs1==0){
                    $dshs=array('id_lop'=>null);
                }else{
                    $dshs=\App\DanhSachHS::where('id_giaovien',$gv['id'])->where('id_hocki',$id_hocki)->first();
                }
                ?>
                <?php $__currentLoopData = $lopday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dshs['id_lop']==$lop['id_lop']): ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e(\App\LopHoc::find($lop['id_lop'])['ten_lop']); ?><span class="label label-success" style="float: right; height: 22px; line-height: 19px;">Chủ nhiệm</span></td>
                            
                            <td><?php echo e($mon['ten_mon']); ?></td>
                            <td><a href="giaovien/nhapdiem/<?php echo e($lop['id_lop']); ?>/<?php echo e($gv['id']); ?>" style="color:#337AB7;">Thêm</a> </td>
                        </tr>
                    <?php else: ?>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e(\App\LopHoc::find($lop['id_lop'])['ten_lop']); ?></td>
                        
                        <td><?php echo e($mon['ten_mon']); ?></td>
                        <td><a href="giaovien/nhapdiem/<?php echo e($lop['id_lop']); ?>/<?php echo e($gv['id']); ?>" style="color:#337AB7;">Thêm</a> </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/giaovien/page/nhapdiem.blade.php ENDPATH**/ ?>