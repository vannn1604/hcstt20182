<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Thông tin cơ bản</h3>
    </div>

    <div class="panel-body">
        <table class="table table-bordered table-striped">
            <tr>
                <th>Họ tên</th>
                <td><?php echo e($vanthu['ho_ten']); ?></td>
            </tr>
            <tr>
                <th>Giới tính</th>
                <td><?php echo e($vanthu['gioi_tinh']); ?></td>
            </tr>
            <tr>
                <th>SĐT</th>
                <td><?php echo e($vanthu['so_dien_thoai']); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($vanthu['email']); ?></td>
            </tr>
            <tr>
                <th>Trường học</th>
                <td><?php echo e(\App\Truong::find($vanthu['id_truong'])['ten_truong']); ?></td>
            </tr>
            <tr>
                <th>Địa chỉ</th>
                <td><?php echo e($vanthu['dia_chi']); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vanthu.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/vanthu/page/tttaikhoan.blade.php ENDPATH**/ ?>