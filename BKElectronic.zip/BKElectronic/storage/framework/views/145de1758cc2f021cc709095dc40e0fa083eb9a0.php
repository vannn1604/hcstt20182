<?php $__env->startSection('content'); ?>
    <div class="panel-body">
        <h3>Giáo viên giảng dạy</h3>
        <table class="table table-bordered table-striped">
            <thead>
            <tr class="info">
                <th>STT</th>
                <th>Họ tên</th>
                <th>Môn học</th>
                <th>Giới tính</th>
                <th>Điện thoại</th>
                <th>Email</th>
                <th>Mã giáo viên</th>
                <th>Sửa</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i=1;
            ?>
            <?php $__currentLoopData = $giaovien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $monhoc=\App\MonHoc::find($gv['id_mon']);
                ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($gv['ho_ten']); ?></td>
                        <td><?php echo e($monhoc['ten_mon']); ?></td>
                        <td><?php echo e($gv['gioi_tinh']); ?></td>
                        <td><?php echo e($gv['so_dien_thoai']); ?></td>
                        <td><?php echo e($gv['email']); ?></td>
                        <td><?php echo e($gv['id_taikhoan']); ?></td>
                        <td><a href="vanthu/giaovien/sua/<?php echo e($gv['id']); ?>" style="color:#337AB7;">Sửa</a> </td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vanthu.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web_Technologies_and_e-Services_project\BKElectronic\resources\views/vanthu/page/dsgiaovien.blade.php ENDPATH**/ ?>