@extends('vanthu.layout.index')
@section('content')
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3 class="table-title">Sửa thư báo</h3>
</div>
<div class="panel-body">
    @if(count($errors)>0)
    <div class="alert alert-danger">
        @foreach($errors->all() as $err)
        {{$err}}<br>
        @endforeach
    </div>
    @endif
    @if(session('thongbao'))
    <div class="alert alert-danger">
        {{session('thongbao')}}
    </div>
    @endif
    @if(session('thanhcong'))
    <div class="alert alert-success">
        {{session('thanhcong')}}
    </div>
    @endif
    <?php
    $u="vanthu/thubao/suathubao/".$thubao['id'];
    ?>
    <form role="form" action="{{ url($u) }}" method="POST" enctype="multipart/form-data">
        {!! csrf_field() !!}
        <div class="form-group">
            <label>Tiêu Đề</label>
            <input class="form-control" name="tieude" value="{{$thubao['tieu_de']}}" placeholder="" />
        </div>
        <div class="form-group">
            <label>Tóm tắt</label>
            <textarea class="form-control" rows="3" name="tomtat">{{$thubao['tom_tat']}}</textarea>
        </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea id="demo" class="ckeditor form-control" rows="3" name="noidung">{{$thubao['noi_dung']}}</textarea>
        </div>
        <div class="form-group">
            <label>Chọn ảnh</label>
            <input type="file" name="Hinh">
        </div>
        <button type="submit"  class="btn btn-primary">Lưu</button>
        <button type="reset" class="btn btn-default">Làm mới</button>
    <form>
</div>

        @endsection