</div>
</div>
</div>
</div>
<!-- Footer -->
<footer class="footer">
    <div class="footer-wrap">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-12" style="padding-right: 40px;">
                    <h3 class="footer-title">Giới thiệu</h3>
                    <div class="text-justify">
                        <p>Chương trình trên là sản phẩm nhóm QVV trong học phần Công nghệ Web và dịch vụ trực tuyến do thầy Đào Thành Trung giảng dạy.</p>
                        <p>Rất mong nhận được những nhận xét và góp ý từ mọi người. Cảm ơn đã theo dõi.</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <h3 class="footer-title">Công nghệ sử dụng</h3>
                    <div class="text-justify">
                        <p>HTML5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CSS</p>
                        <p>Javascript&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MySQL</p>
                        <p>Laravel</p>
                    </div>
                </div> 
                <div class="col-md-4 col-sm-12">
                    <h3 class="footer-title">Nhóm phát triển</h3>
                    <div class="text-justify">
                        <p>Dương Minh Quang</p>
                        <p>Nguyễn Ngọc Văn</p>
                        <p>Trần Văn Viên</p>
                    </div>
                </div> 
            </div>
        </div>
        <div id="copyright">
            <div>© 2019 Copyright:
                <a href="https://www.facebook.com/BK-Electronic-852825004901145/"> BKElectronic</a>
            </div>
        </div>
    </div>
</footer>