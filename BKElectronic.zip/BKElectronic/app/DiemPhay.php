<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiemPhay extends Model
{
    //
    protected $table = "diem_phay";
    public $timestamps = false;
}
