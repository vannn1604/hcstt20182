<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeSo2 extends Model
{
    //
    protected $table = "he_so2";
    public $timestamps = false;
}
