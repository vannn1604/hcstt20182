<?php $__env->startSection('content'); ?>
    <!-- Title -->
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3 class="table-title"><i class="fa icon-envelope"></i><?php echo e($thongbao['tieu_de']); ?></h3>
    
</div>
<div class="panel-body">
    <p>by <?php echo e(\App\VanThu::find($thongbao['id_vanthu'])['ho_ten']); ?></p>
    <p><span class="glyphicon glyphicon-time"></span> <?php echo e($thongbao['created_at']); ?></p>
    <hr>

    <!-- <h1><?php echo e($thongbao['tieu_de']); ?></h1> -->
    <!-- Author -->
    <!-- <p>
    <p>by <?php echo e(\App\VanThu::find($thongbao['id_vanthu'])['ho_ten']); ?></p>
    </p> -->
    <!-- <p><span class="glyphicon glyphicon-time"></span> <?php echo e($thongbao['created_at']); ?></p>
    <hr> -->

    <!-- Post Content -->
    <p class="lead"><?php echo e($thongbao['tom_tat']); ?></p>
    <!-- <img class="img-responsive" src="image/<?php echo e($thongbao['image']); ?>" alt=""> -->
    
    <?php echo $thongbao['noi_dung']; ?>



</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('hocsinh.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/hocsinh/page/detalthongbao.blade.php ENDPATH**/ ?>