@extends('vanthu.layout.index')
@section('content')
    <!-- Title -->
 <!--    <h1>{{$thongbao['tieu_de']}}</h1>
    <p>
    <p>by {{\App\VanThu::find($thongbao['id_vanthu'])['ho_ten']}}</p>
    </p>
    <p><span class="glyphicon glyphicon-time"></span> {{$thongbao['created_at']}}</p>
    <hr>

    <p class="lead">{{$thongbao['tom_tat']}}</p>
    <img class="img-responsive" src="image/{{$thongbao['image']}}" alt="">
    <hr>
    <hr>
    {!!$thongbao['noi_dung'] !!}

    <hr> -->
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3 class="table-title">{{$thongbao['tieu_de']}}</h3>
    
</div>
<div class="panel-body">
    <p>by {{\App\VanThu::find($thongbao['id_vanthu'])['ho_ten']}}</p>
    <p><span class="glyphicon glyphicon-time"></span> {{$thongbao['created_at']}}</p>
    <hr>
    <p class="lead">{{$thongbao['tom_tat']}}</p>
    <img class="img-responsive" src="image/{{$thongbao['image']}}" alt="">
    
    {!!$thongbao['noi_dung'] !!}


</div>
@endsection