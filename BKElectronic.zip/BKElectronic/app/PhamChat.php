<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PhamChat extends Model
{
    //
    protected $table = "pham_chat";
    public $timestamps = false;
}
