<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BangTongKet extends Model
{
    //
    protected $table = "bang_tong_ket";
    public $timestamps = false;
}
