@extends('vanthu.layout.index')
@section('content')
    <!-- Title -->
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3 class="table-title">{{$thubao['tieu_de']}}</h3>
</div>
<div class="panel-body">
    <p>by {{\App\VanThu::find($thubao['id_vanthu'])['ho_ten']}}</p>
    <p><span class="glyphicon glyphicon-time"></span> {{$thubao['created_at']}}</p>
    <hr>
    <p class="lead">{{$thubao['tom_tat']}}</p>
    <img class="img-responsive" src="image/{{$thubao['image']}}" alt="">
    
    {!!$thubao['noi_dung'] !!}

@endsection