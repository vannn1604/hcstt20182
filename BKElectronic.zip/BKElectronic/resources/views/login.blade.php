<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BKElectronic</title>
    <!-- <base href="{{asset('')}}"> -->
    <!-- Bootstrap Core CSS -->
    <!-- <link href="front_asset/css/bootstrap.min.css" rel="stylesheet"> -->

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        * {
          box-sizing: border-box;
      }


      #myVideo {
          position: fixed;
        left: -200px;
          top: -100px;
          min-width: 100%; 
          min-height: 100%;
      }

      .content {

          position: fixed;
          bottom: 0;
          /*background: rgba(0, 0, 0, 0.1);*/
          color: #f1f1f1;
          width: 100%;
          padding: 20px;
      }


      html, body {
        width:100%;
        height:100%;
    }
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
    .box {

        position: absolute;
        top: 45%;
        left: 51%;
        transform: translate(-50%,-50%);
        width: 400px;
        padding: 40px 40px 30px 40px;
        box-sizing: border-box;
        box-shadow: 0 15px 25px rgba(0,0,0,.9);
        /*box-shadow: 0px 0px 10px #343434;*/
        border-radius: 10px;
    }
    .box h2 {
        margin: 0 0 30px;
        padding: 0;
        color: #FFF;
        text-align: center;
    }

    .box .inputBox {
        position: relative;
    }
    .box .inputBox input {
        width: 100%;
        padding: 10px 0 7px 0;
        font-size: 16px;
        color: #FFF;
        letter-spacing: 1px;
        margin-bottom: 30px;
        border: none;
        border-bottom: 1px solid #FFF;
        outline: none;
        background: transparent;
    }
    .box .inputBox label {
        position: absolute;
        top: 0;
        left: 0;
        padding: 10px 0;
        font-size: 16px;
        color: #FFF;
        pointer-events: none;
        transition: .5s;
        animation: LabelOnLoad 1s forwards 0s ease;
    }
    @keyframes LabelOnLoad{
        0%{
            transform: rotate(0) translateY(-19px);
            opacity: 0;
        }
        100%{
            transform: rotate(0) translateY(0);
            opacity: 1;
        }
    }
    .box .inputBox input:focus ~ label, 
    .box .inputBox input:valid ~ label {
        top: -22px;
        left:0;
        color: #03A9F4;
        font-size: 15px;
    }
    .box input[type='submit'] {
        background: transparent;
        border: none;
        outline: none;
        color: #FFF;
        box-shadow: 0 15px 25px rgba(0,0,0,.9);
        /*background: #03A9F4;*/
        padding: 10px 20px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 14px;
    }
    .box input[type='submit']:hover {
        /*background-color: rgba(3, 169, 244, 0.7);*/
        background-color: #03A9F4;
    }
    @media(max-width: 720px){
        .box {
            width: 80%;
        }
    }
    .box > div:first-child {
        height: 80%; 
        width: 80%; 
        padding-left: 20%; 
        margin-top: -3%; 
        margin-bottom: 35px;
    }
    input:-webkit-autofill,
input:-internal-autofill-selected,
input:-webkit-autofill:hover, 
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  -webkit-text-fill-color: #fff;
  /*-webkit-box-shadow: 0 0 0px 1000px none inset;*/
  transition: background-color 5000s ease-in-out 0s;
}

#thongbao {
    margin-bottom: 35px;
    color: red;
}

</style>
</head>

<body>
    <video autoplay muted loop id="myVideo">
      <source src="image/22363133.mp4" type="video/mp4">
          
      </video>
      <div class="box content" style="position: relative;">
        <!-- <h2>Đăng nhập hệ thống</h2> -->
        <div class="inputBox">
            <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"  />
        </div>
        <div id="thongbao">
        @if(count($errors)>0)
            <div class="alert alert-danger">
                @foreach($errors->all() as $err)
                    {{$err}}<br>
                @endforeach
            </div>
        @endif
        @if(session('thongbao'))
            <div class="alert alert-danger">
            {{session('thongbao')}}
            </div>
        @endif
        </div>
        <form role="form" action="{{ url('/login') }}" method="POST">
            {!! csrf_field() !!}
            <div class="inputBox">
                <input type="text" name="username" />
                <label for="">Tài khoản</label>
            </div>
            <div class="inputBox">
                <input type="password" name="password" />
                <label for="">Mật khẩu</label>
            </div>
            <div style="padding-left: 32%;">
                <input type="submit" value="Đăng nhập" >
            </div>
            
        </form>
    </div>


    <!-- end Footer -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/my.js"></script>

</body>

</html>
