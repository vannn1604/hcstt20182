
    

<?php echo e(Auth::user()->name); ?>

<h1>Hello</h1>
<?php /**PATH C:\xampp\htdocs\Web_Technologies_and_e-Services_project\BKElectronic\resources\views/vanthu/index.blade.php ENDPATH**/ ?>