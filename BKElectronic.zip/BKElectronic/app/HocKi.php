<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HocKi extends Model
{
    //
    protected $table = "hoc_ki";
    public $timestamps = false;
}
