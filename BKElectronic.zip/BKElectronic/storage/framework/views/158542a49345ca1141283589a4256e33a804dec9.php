<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <div class="semyear-choice">
            <ul>
                <li>
                    <br>
                    <br>
                </li>
            </ul>
        </div>
    </div>
    <?php if(session('thanhcong')): ?>
        <div class="alert alert-success">
            <?php echo e(session('thanhcong')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('thongbao')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('thongbao')); ?>

        </div>
    <?php endif; ?>
    <?php
    $u="giaovien/nhapdiem/$id_lop/$id_giaovien";
    ?>

    <div class="panel-body">
        <form role="form" action="<?php echo e(url($u)); ?>" method="PUT">
            <?php echo csrf_field(); ?>

            <table class="table table-bordered">
                <caption style="text-align: center; font-size: 15px; font-weight: bold;">Môn Toán</caption>
                <thead>
                <tr class="info">
                    <th>STT</th>
                    <th>Họ tên</th>
                    <th colspan="3">Hệ số 1</th>
                    <th colspan="2">Hệ số 2</th>
                    <th>Hệ số 3</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i=1;
                $giaovien=\App\GiaoVien::find($id_giaovien);
                ?>
                <?php $__currentLoopData = $hocsinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $tongket = \App\BangTongKet::where('id_hocsinh',$hs['id'])->first();
                    $dsbd = \App\DanhSachBD::where('id_tongket', $tongket['id'])->first();
                    $bd=\App\BangDiem::Where('id_danh_sach_bd',$dsbd['id'])->where('id_giaovien', $giaovien['id'])->where('id_mon', $giaovien['id_mon'])->count();
                    ?>
                    <?php if($bd==0): ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($hs['ho_ten']); ?></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="" name="diem1<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="" name="diem2<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value=""  name="diem3<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value=""  name="diem4<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value=""  name="diem5<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="" name="diem6<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                        </tr>
                    <?php else: ?>
                        <?php
                        $bangdiem=\App\BangDiem::Where('id_danh_sach_bd',$dsbd['id'])->where('id_giaovien', $giaovien['id'])->where('id_mon', $giaovien['id_mon'])->first();
                        $heso1=\App\HeSo1::Where('id_bangdiem',$bangdiem['id'])->get();
                        $heso2=\App\HeSo2::Where('id_bangdiem',$bangdiem['id'])->get();
                        $heso3=\App\HeSo3::Where('id_bangdiem',$bangdiem['id'])->first();
                       // $diemphay=\App\DiemPhay::Where('id_bangdiem',$bangdiem['id'])->first();
                        ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($hs['ho_ten']); ?></td>
                            <?php
                                $j=1;
                            ?>
                            <?php $__currentLoopData = $heso1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="<?php echo e($hs1['diem']); ?>" name="diem<?php echo e($j++); ?><?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $heso2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="<?php echo e($hs2['diem']); ?>"  name="diem<?php echo e($j++); ?><?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="position: relative;"><input type=number step=0.1 min="0" max="10" value="<?php echo e($heso3['diem']); ?>" name="diem6<?php echo e($hs['id']); ?>" style="position: absolute; top: 0; left: 0; bottom: 0; right: 0;width: 100%; border: none;" /></td>

                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="giaovien/nhapdiem" class="btn btn-basic" style="float: right; margin-left: 5px;">Hủy bỏ</a>
            <button type="submit" class="btn btn-primary" style="float: right; ">Lưu</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web_Technologies_and_e-Services_project\BKElectronic\resources\views/giaovien/page/themdiem.blade.php ENDPATH**/ ?>