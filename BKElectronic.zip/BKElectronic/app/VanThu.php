<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VanThu extends Model
{
    //
    protected $table = "van_thu";
    public $timestamps = false;
}
