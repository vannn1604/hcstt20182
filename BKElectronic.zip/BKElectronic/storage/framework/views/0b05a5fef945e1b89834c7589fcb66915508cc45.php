<?php $__env->startSection('content'); ?>
    <div class="panel-heading" style="background-color:#337AB7; color:white;" >
        <h3>Danh sách lớp học</h3>
    </div>

    <div class="panel-body">
        <table class="table table-bordered table-striped">
            <thead>
            <tr class="info">
                <th>STT</th>
                <th>Tên lớp</th>
                <th>Danh sách giảng dạy</th>

            </tr>
            </thead>
            <tbody>
            <?php
            $i=1;
            $user=\Illuminate\Support\Facades\Auth::user();
            $vanthu=\App\VanThu::where('id_taikhoan',$user['id'])->orderBy('id', 'desc')->first();
            $lophoc=\App\LopHoc::Where('id_truong',$vanthu['id_truong'])->get();
            ?>

            <?php $__currentLoopData = $lophoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                ?>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($lop['ten_lop']); ?></td>
                <td><a href="vanthu/giangday/dsgiangday/<?php echo e($lop['id']); ?>" style="color:#337AB7;">Xem chi tiết</a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('vanthu.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/vanthu/giangday/dsgiangday.blade.php ENDPATH**/ ?>