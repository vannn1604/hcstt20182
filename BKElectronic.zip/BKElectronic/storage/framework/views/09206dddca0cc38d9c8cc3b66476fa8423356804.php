<?php $__env->startSection('content'); ?>

<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3 class="table-title"></i><?php echo e($thubao['tieu_de']); ?></h3>
    
</div>
<div class="panel-body">
    <p>by <?php echo e(\App\VanThu::find($thubao['id_vanthu'])['ho_ten']); ?></p>
    <p><span class="glyphicon glyphicon-time"></span><?php echo e($thubao['created_at']); ?></p>
    <hr>
    <p class="lead"><?php echo e($thubao['tom_tat']); ?></p>
    <img class="img-responsive" src="image/<?php echo e($thubao['image']); ?>" alt="">
    <?php echo $thubao['noi_dung']; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovien.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/giaovien/page/detalthubao.blade.php ENDPATH**/ ?>