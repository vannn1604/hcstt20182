<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeSo3 extends Model
{
    //
    protected $table = "he_so3";
    public $timestamps = false;
}
