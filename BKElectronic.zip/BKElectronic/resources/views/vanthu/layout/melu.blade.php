<div class="row main-left">
    <div class="col-md-3 ">
        <ul class="list-group" id="menu">
            <li href="#" class="list-group-item menu1 active">Menu</li>
            <li href="#" class="list-group-item menu1">
                Quản lý thông báo
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/thongbao/dsthongbao">Danh sách thông báo</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/thongbao/themthongbao"">Thêm thông báo</a>
                </li>

            </ul>
            <li href="#" class="list-group-item menu1">
                Quản lý thư báo
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/thubao/dsthubao">Danh sách thư báo</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/thubao/themthubao"">Thêm thư báo</a>
                </li>

            </ul>
            <li href="#" class="list-group-item menu1">
                Quản lý giáo viên
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/giaovien/dsgiaovien">Danh sách giáo viên</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/giaovien/themgiaovien"">Thêm giáo viên</a>
                </li>

            </ul>
            <li href="#" class="list-group-item menu1">
                Quản lý giảng dạy
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/giangday/dsgiangday">Danh sách giảng dạy</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/giangday/themgiangday"">Thêm giảng dạy</a>
                </li>
            </ul>

            <li href="#" class="list-group-item menu1">
                Quản lý học sinh
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/hocsinh/dshocsinh">Danh sách học sinh</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/hocsinh/themhocsinh"">Thêm học sinh</a>
                </li>
            </ul>

            <li href="#" class="list-group-item menu1">
                Quản lý tài khoản
            </li>
            <ul>
                <li class="list-group-item">
                    <a href="vanthu/taikhoan/tttaikhoan">Thông tin cá nhân</a>
                </li>
                <li class="list-group-item">
                    <a href="vanthu/taikhoan/doimatkhau">Đổi mật khẩu</a>
                </li>
            </ul>

            <li href="#" class="list-group-item menu1">
                <a href="logout">Đăng xuất</a>
            </li>
        </ul>
    </div>
    
