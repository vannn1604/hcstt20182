<?php $__env->startSection('content'); ?>
<div class="panel-heading" style="background-color:#337AB7; color:white;" >
    <h3>Thêm thư báo</h3>
</div>
<!-- /.col-lg-12 -->

<div class="panel-body">
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($err); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <?php if(session('thongbao')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('thongbao')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('thanhcong')): ?>
    <div class="alert alert-success">
        <?php echo e(session('thanhcong')); ?>

    </div>
    <?php endif; ?>
    <form role="form" action="<?php echo e(url('vanthu/thubao/themthubao')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Tiêu Đề</label>
            <input class="form-control" name="tieude" placeholder="" />
        </div>
        <div class="form-group">
            <label>Tóm tắt</label>
            <textarea class="form-control" rows="3" name="tomtat"></textarea>
        </div>
        <div class="form-group">
            <label>Nội dung</label>
            <textarea id="demo" class="ckeditor form-control" rows="3" name="noidung"></textarea>
        </div>
        <div class="form-group">
            <label>Chọn ảnh</label>
            <input type="file" name="Hinh">
        </div>
        <button type="submit"  class="btn btn-primary">Thêm</button>
        <button type="reset" class="btn btn-default">Làm mới</button>
    <form>
</div>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('vanthu.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BKElectronic\resources\views/vanthu/page/themthubao.blade.php ENDPATH**/ ?>