<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GiuaKiC1 extends Model
{
    //
    protected $table = "giua_ki_c1";
    public $timestamps = false;
}
